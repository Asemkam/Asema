package evgeny.company.appwithfrags

interface MyRouter {
    fun openSecondFragment()
}